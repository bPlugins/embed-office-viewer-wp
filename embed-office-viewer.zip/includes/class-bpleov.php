<?php
namespace BPLEOV;
use BPLEOV\Helper\BPLEOV_Functions as Functions;

class BPLEOV_Main {

    private static $_instance = null;

    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    public function __construct() {
        add_action( 'init', [$this, 'init'], 0 );
        add_action( 'plugins_loaded', [$this, 'load_dependencies'] );
        add_action( 'plugins_loaded', [__CLASS__, 'load_textdomain'] );
        add_action( 'wp_enqueue_scripts', [$this, 'bpleov_public_scripts'] );
        add_action( 'admin_notices', [$this, 'upgrade_notice'] );
    }

    public function init() {
        if ( ! class_exists( 'CSF' ) ) {
            require_once BPLEOV_PLUGIN_PATH . 'vendor/codestar-framework/codestar-framework.php';
        }

        if ( function_exists( 'bpleov_fs' ) && bpleov_fs()->is_free_plan() ) {
            \BPLEOV\BPLEOV_MetaboxFree::init();
        }
    }

    public function load_dependencies() {
        new \BPLEOVPlugin();

        // Initialize singletons (auto-loaded by Composer)
        \BPLEOV\Core\BPLEOV_OfficeViewer::instance();
        \BPLEOV\Admin\BPLEOV_Admin::instance();
        \BPLEOV\Services\BPLEOV_ShortcodeFree::instance();

        // In-admin help chatbot (self-instantiates and registers at file end).
        require_once BPLEOV_PLUGIN_PATH . 'includes/admin/class-bpleov-chatbot.php';
    }

    public static function load_textdomain() {
        // phpcs:ignore PluginCheck.CodeAnalysis.DiscouragedFunctions.load_plugin_textdomainFound, WordPress.WP.DeprecatedFunctions.load_plugin_textdomainFound
        load_plugin_textdomain( 'embed-office-viewer', false, dirname( dirname( __FILE__ ) ) . '/languages' );
    }



    public function bpleov_public_scripts() {
        wp_enqueue_script( 'bpleov', BPLEOV_PLUGIN_DIR . 'assets/js/script.js', array(), BPLEOV_VERSION, true );
    }

    public function upgrade_notice() {
        $page = get_current_screen();
        if ( ! $page ) {
            return;
        }
        $is_office_viewer_page = $page->base == 'edit' && $page->post_type == 'officeviewer';
        if ( $page->base == 'officeviewer_page_bpleov-onedrive' || $page->base == 'officeviewer_page_eov-onedrive' || $is_office_viewer_page ) {
        ?>
        <div class="eov_upgrade_notice <?php echo esc_attr( $is_office_viewer_page ? 'officeviewer' : 'settings' ) ?> ">
            <div class="flex">
                <img src="<?php echo esc_url( BPLEOV_PLUGIN_DIR . 'assets/images/icon.png' ) ?>" alt="Office Viewer" />
                <h3>Office Viewer</h3>
            </div>
            <p>The Ultimate Document Viewer Plugin for WordPress, Loved by Over 2,000+ Users.</p>
            <div>
                <a href="<?php echo esc_url( admin_url( 'edit.php?post_type=officeviewer&page=embed-office-viewer-pricing' ) ) ?>" class="button button-primary" target="_blank">Upgrade To Pro <svg enable-background="new 0 0 515.283 515.283" height="16" viewBox="0 0 515.283 515.283" width="16" xmlns="http://www.w3.org/2000/svg">
                        <g>
                            <g>
                                <g>
                                    <g>
                                        <path d="m372.149 515.283h-286.268c-22.941 0-44.507-8.934-60.727-25.155s-25.153-37.788-25.153-60.726v-286.268c0-22.94 8.934-44.506 25.154-60.726s37.786-25.154 60.727-25.154h114.507c15.811 0 28.627 12.816 28.627 28.627s-12.816 28.627-28.627 28.627h-114.508c-7.647 0-14.835 2.978-20.241 8.384s-8.385 12.595-8.385 20.242v286.268c0 7.647 2.978 14.835 8.385 20.243 5.406 5.405 12.594 8.384 20.241 8.384h286.267c7.647 0 14.835-2.978 20.242-8.386 5.406-5.406 8.384-12.595 8.384-20.242v-114.506c0-15.811 12.817-28.626 28.628-28.626s28.628 12.816 28.628 28.626v114.507c0 22.94-8.934 44.505-25.155 60.727-16.221 16.22-37.788 25.154-60.726 25.154zm-171.76-171.762c-7.327 0-14.653-2.794-20.242-8.384-11.179-11.179-11.179-29.306 0-40.485l237.397-237.398h-102.648c-15.811 0-28.626-12.816-28.626-28.627s12.815-28.627 28.626-28.627h171.761c3.959 0 7.73.804 11.16 2.257 3.201 1.354 6.207 3.316 8.837 5.887.001.001.001.001.002.002.019.019.038.037.056.056.005.005.012.011.017.016.014.014.03.029.044.044.01.01.019.019.029.029.011.011.023.023.032.032.02.02.042.041.062.062.02.02.042.042.062.062.011.01.023.023.031.032.011.01.019.019.029.029.016.015.03.029.044.045.005.004.012.011.016.016.019.019.038.038.056.057 0 .001.001.001.002.002 2.57 2.632 4.533 5.638 5.886 8.838 1.453 3.43 2.258 7.2 2.258 11.16v171.761c0 15.811-12.817 28.627-28.628 28.627s-28.626-12.816-28.626-28.627v-102.648l-237.4 237.399c-5.585 5.59-12.911 8.383-20.237 8.383z" fill="rgba(255, 255, 255, 1)" />
                                    </g>
                                </g>
                            </g>
                        </g>
                    </svg></a>
            </div>
        </div>
       <?php
        }
    }

}
